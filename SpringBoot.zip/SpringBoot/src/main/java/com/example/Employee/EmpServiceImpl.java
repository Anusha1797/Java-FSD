package com.example.Employee;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmpServiceImpl implements IEmpService
{
	@Autowired
    private IEmpDao dao;
	public List<Employee> getAllEmployees() {
		
		return dao.findAll();
				
	}

	@Override
	public Optional<Employee> getEmployeeById(int id) {
		
		return dao.findById(id);
	}
	@Override
	public Employee getEmployeeByName(String name) {
		
			return dao.findEmployeeByName(name);
	}
	@Override
	public Employee findUsingNameAddr(String name,String addr){
		return dao.findUsingNameAddr(name,addr);
	}

	@Override
	public Integer createOrUpdate(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteById(Integer employeeId) {
		// TODO Auto-generated method stub
		
	
	}

	@Override
	public Employee update(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Employee updateAddr(Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}
	
}


