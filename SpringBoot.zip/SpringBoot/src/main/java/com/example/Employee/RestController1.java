package com.example.Employee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringBootJpa.IEmpService;

@RestController
public class RestController1 
{
	@Autowired
     private IEmpService Serv;
}
