package com.example.Employee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestController1 
{
	@Autowired
     private IEmpService Service;
	@RequestMapping("getAll")
	public List<Employee> getAll()
	{
		
		return Service.getAllEmployees();
	}
	
	@RequestMapping("getByName/{ename}")
	public Employee getEmployeeByName(@PathVariable("ename") String name)
	{
		
		return Service.getEmployeeByName(name);
	}
	
//	@RequestMapping("getByNameAddr/{ename}/{addr}")
//	public Person getUsingNameAddress(@PathVariable("ename") String name, @PathVariable("addr") String ad) {
//		return service.findUsingNameAddress(name, ad);
//	}
	
	@RequestMapping(value = "/person", method = RequestMethod.POST, produces = "application/json")
	public Integer createOrUpdate (@RequestBody Employee employee) 
	{
		
		return Service.createOrUpdate(employee);
	}
	
	@RequestMapping(value = "deleteById/{eid}", method = RequestMethod.DELETE)
	public void deleteById(@PathVariable("eid") Integer employeeId) 
	{
		
		Service.deleteById(employeeId);
	}
	
	@RequestMapping(value="/update", method = RequestMethod.PUT)
	public Employee updatePerson(@RequestBody Employee employee) 
	{
		
		return Service.update(employee);
	}
	
	@RequestMapping(value="/updateAddr", method = RequestMethod.PATCH)
	public Employee updateEmployeeAddr(@RequestBody Employee employee)
	{
		
		return Service.updateAddr(employee);
	}
	
	
}


