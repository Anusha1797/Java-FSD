package com.example.Employee;

import java.util.List;
import java.util.Optional;

public interface IEmpService
{
	public List<Employee> getAllEmployees();
	public Optional<Employee> getEmployeeById(int id);
	public Employee getEmployeeByName(String name) ;
	public Employee findUsingNameAddr(String name,String addr);
	public Integer createOrUpdate(Employee employee);
	public void deleteById(Integer employeeId);
	public Employee update (Employee employee); 
	public Employee updateAddr(Employee employee);
}
