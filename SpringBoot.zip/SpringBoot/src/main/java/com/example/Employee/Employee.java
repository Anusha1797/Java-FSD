package com.example.Employee;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Employee implements Serializable
{
	 @Id
	 @GeneratedValue(strategy=GenerationType.IDENTITY)
	 private Integer empid;
	 private String empName;
	 private String empAddr;
	 
	 public Employee()
	 {
		 
	 }
	public Employee(Integer empid, String empName, String empAddr) {
		this.empid = empid;
		this.empName = empName;
		this.empAddr = empAddr;
	}
	public Integer getEmpid() {
		return empid;
	}
	public void setEmpid(Integer empid) {
		this.empid = empid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getEmpAddr() {
		return empAddr;
	}
	public void setEmpAddr(String empAddr) {
		this.empAddr = empAddr;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empName=" + empName + ", empAddr=" + empAddr + "]";
	}
	
     
}
