package com.example.Employee;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IEmpDao extends JpaRepository <Employee,Integer>
{

}
