package com.example.SpringBootJpa;

public interface IEmpService
{
  
}
