package com.example.SpringBootJpa;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.Employee.Employee;

@Repository
public interface IEmpDao extends JpaRepository <Employee,Integer>
{

}
