import { Component, OnInit } from '@angular/core';
import { Cart } from '../cart';
import { SellerServiceService } from '../seller-service.service';

@Component({
  selector: 'app-displaycartitems',
  templateUrl: './displaycartitems.component.html',
  styleUrls: ['./displaycartitems.component.css']
})
export class DisplaycartitemsComponent implements OnInit {

  cart: Cart;
  constructor(private sellerservice: SellerServiceService) { }

  ngOnInit() {
  }
  displaycart() {
    console.log("displaycartitems");
    this.sellerservice.getitemByid().subscribe(cart=>this.cart=cart);

  }
 deleteitem() {
   console.log("itemdeleted");
   this.sellerservice. deleteitemById()

 } 

}
