export class Cart {
    cartid: number;
    itemid: number;
    numberofitems: number;
    price: number
}