package com.example.product.Dao;

import com.example.product.Service.CartItemService;
import com.example.product.model.ShoppingCart;

public interface CartItemDao {

	CartItemService save(ShoppingCart cart);

	CartItemService update(CartItemService cartitemservice);

}
