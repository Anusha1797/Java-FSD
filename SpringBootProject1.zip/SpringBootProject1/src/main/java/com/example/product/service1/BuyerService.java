package com.example.product.service1;

import org.springframework.stereotype.Service;

import com.example.product.Entity.Buyerdetails;


public interface BuyerService
{
	public Buyerdetails addbuyer(Buyerdetails buyer);

}
