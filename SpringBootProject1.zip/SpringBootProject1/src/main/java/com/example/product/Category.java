package com.example.product;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Category implements Serializable
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int categoryid;
	@Column(name="category_name")
	private String categoryname;
	private String briefdetails;
	@OneToMany
	@JoinColumn(name="CATEGORYID_KEY")
	private List<SubCategory> subcategory;
	
	
	
	public List<SubCategory> getSubCategory() {
		return subcategory;
	}

	public void setSubCategory(List<SubCategory> subCategory) {
		subcategory = subCategory;
	}

	public Category()
	{
		
	}

	public Category(int categoryid, String categoryname, String briefdetails) {
		super();
		this.categoryid = categoryid;
		this.categoryname = categoryname;
		this.briefdetails = briefdetails;
	}

	public int getCategoryid() {
		return categoryid;
	}

	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}

	public String getCategoryname() {
		return categoryname;
	}

	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}

	public String getBriefdetails() {
		return briefdetails;
	}

	public void setBriefdetails(String briefdetails) {
		this.briefdetails = briefdetails;
	}

	@Override
	public String toString() {
		return "Category [categoryid=" + categoryid + ", categoryname=" + categoryname + ", briefdetails="
				+ briefdetails + "]";
	}
	
	
	
	

}
