package com.example.product.Controller;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.product.Service.BuyerService;
import com.example.product.model.Buyerdetails;



@RestController
public class BuyerController
{
	@Autowired
	private BuyerService service;
	
	 
	 @RequestMapping(value="/addBuyer", method=RequestMethod.POST,produces="applicaion/json" )
	 public Buyerdetails addbuyer(@RequestBody Buyerdetails buyer)
	 {
		 return service.addbuyer(buyer);
	 }
	 
	  
	 

}
