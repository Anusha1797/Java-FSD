package com.example.product.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.product.model.Buyerdetails;

public interface BuyerDao {

	Buyerdetails save(Buyerdetails buyer);


}
