package com.example.product.Service;

import com.example.product.Dao.CartItemDao;
import com.example.product.model.ShoppingCart;

public class CartItemServiceImpl  implements CartItemService
{
	private CartItemDao cartdao;

	@Override
	public CartItemService addcartitem(ShoppingCart cart)
	{
		return cartdao.save(cart);
	}

	@Override
	public  void deleteById(Integer cartid)
	{
       return;
		
	}

	@Override
	public CartItemService update(CartItemService cartitemservice) {
		
		return cartdao.update(cartitemservice);
	}
	

}
