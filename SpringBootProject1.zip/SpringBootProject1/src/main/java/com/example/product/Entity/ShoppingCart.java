package com.example.product.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class ShoppingCart 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int cartid;
	private int cartquantity;
	@ManyToOne
	@JoinColumn(name="buyerid_key")
	private Buyerdetails buyerdetails;
	
	public ShoppingCart()
	{
		
	}

	public ShoppingCart(int cartid, int cartquantity, Buyerdetails buyerdetails) {
		super();
		this.cartid = cartid;
		this.cartquantity = cartquantity;
		this.buyerdetails = buyerdetails;
	}

	public int getCartid() {
		return cartid;
	}

	public void setCartid(int cartid) {
		this.cartid = cartid;
	}

	public int getCartquantity() {
		return cartquantity;
	}

	public void setCartquantity(int cartquantity) {
		this.cartquantity = cartquantity;
	}

	public Buyerdetails getBuyerdetails() {
		return buyerdetails;
	}

	public void setBuyerdetails(Buyerdetails buyerdetails) {
		this.buyerdetails = buyerdetails;
	}

	@Override
	public String toString() {
		return "ShoppingCart [cartid=" + cartid + ", cartquantity=" + cartquantity + ", buyerdetails=" + buyerdetails
				+ "]";
	}
	
	

}
