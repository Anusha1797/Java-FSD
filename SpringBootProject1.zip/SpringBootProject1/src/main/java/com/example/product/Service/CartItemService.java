package com.example.product.Service;

import com.example.product.model.ShoppingCart;

public interface CartItemService 
{
	public CartItemService addcartitem(ShoppingCart cart);

	public void deleteById(Integer cartid);

	public CartItemService update(CartItemService cartitemservice);

}
