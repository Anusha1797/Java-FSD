package com.example.product.service1;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.example.product.Entity.Buyerdetails;
import com.example.product.dao1.BuyerDao;

@Service
public class BuyerServiceImpl implements BuyerService
{
	@Autowired(required=true)
	private BuyerDao buyerdao;
	
	public Buyerdetails addbuyer(Buyerdetails buyer) {
	
		return buyerdao.save(buyer);
	}

}
