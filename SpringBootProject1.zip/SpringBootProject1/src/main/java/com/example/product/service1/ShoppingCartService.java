package com.example.product.service1;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.product.Entity.Buyerdetails;
import com.example.product.Entity.ShoppingCart;
import com.example.product.dao1.BuyerDao;
import com.example.product.dao1.CartRepository;



public class ShoppingCartService 
{
	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private BuyerDao buyerdao;
	
	public List<ShoppingCart> getAllCartItems(Integer buyerId){
		return cartRepository.findAll();
	}
	
	public Optional<ShoppingCart> addCartItem(ShoppingCart shoppingCartItem, Integer buyerId) {
		return buyerdao.findById(buyerId).map(buyer -> {
			shoppingCartItem.setBuyerdetails(buyer);
			return cartRepository.save(shoppingCartItem);
		});
		
	}
	
	public String deleteCartItemById(Integer cartItemId) {
		cartRepository.deleteById(cartItemId);
		return "Item with cartId"+cartItemId+" is deleted.";
	}

	

	//public void deleteByBuyerId(Integer buyerId) {
		// TODO Auto-generated method stub
		
	

	//public ShoppingCart updateCart(ShoppingCart shoppingCartItem, Integer cartItemId) {
		
         //Optional<ShoppingCart> cartItem = cartRepository.findById(cartItemId);
		
		/*if(cartItem.isPresent()) {
		cartItem = cartItem.get();
		cartItem.setItemQuantity(shoppingCartItem.getCartquantity());
		
		return cartRepository.save(cartItem);*/
	
}	
		
	
	



	





