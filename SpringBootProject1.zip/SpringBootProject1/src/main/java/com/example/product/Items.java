package com.example.product;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Items implements Serializable
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int itemid;
	@Column(name="item_name")
	private String itemname;
	private int price;
	private String description;
	@Column(name="stock_number")
	private int stocknumber;
	private String remarks;
	/*@ManyToOne
	@JoinColumn(name="subcategory_id")
	private SubCategory subcategory;
	
	
	public SubCategory getSubcategory() {
		return subcategory;
	}
	public void setSubcategory(SubCategory subcategory) {
		this.subcategory = subcategory;
	}*/
	public Items()
	{
		
	}
	public Items(int itemid, String itemname, int price, String description, int stocknumber, String remarks) {
		super();
		this.itemid = itemid;
		this.itemname = itemname;
		this.price = price;
		this.description = description;
		this.stocknumber = stocknumber;
		this.remarks = remarks;
	}
	public int getItemid() {
		return itemid;
	}
	public void setItemid(int itemid) {
		this.itemid = itemid;
	}
	public String getItemname() {
		return itemname;
	}
	public void setItemname(String itemname) {
		this.itemname = itemname;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStocknumber() {
		return stocknumber;
	}
	public void setStocknumber(int stocknumber) {
		this.stocknumber = stocknumber;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "Items [itemid=" + itemid + ", itemname=" + itemname + ", price=" + price + ", description="
				+ description + ", stocknumber=" + stocknumber + ", remarks=" + remarks + "]";
	}
	
	
	
	

}
