package com.example.product;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PurchaseHistory implements Serializable
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int purchaseid;
	@Column(name="no_of_items")
	private int totalitems;
	@Column(name="date_time")
	private Date datetime;
	private String remarks;
	
	public PurchaseHistory()
	{
		
	}

	public PurchaseHistory(int purchaseid, int totalitems, Date datetime, String remarks) {
		super();
		this.purchaseid = purchaseid;
		this.totalitems = totalitems;
		this.datetime = datetime;
		this.remarks = remarks;
	}

	public int getPurchaseid() {
		return purchaseid;
	}

	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}

	public int getTotalitems() {
		return totalitems;
	}

	public void setTotalitems(int totalitems) {
		this.totalitems = totalitems;
	}

	public Date getDatetime() {
		return datetime;
	}

	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	@Override
	public String toString() {
		return "PurchaseHistory [purchaseid=" + purchaseid + ", totalitems=" + totalitems + ", datetime=" + datetime
				+ ", remarks=" + remarks + "]";
	}
	
	
	

}
