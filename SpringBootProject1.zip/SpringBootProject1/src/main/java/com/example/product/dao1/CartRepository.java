package com.example.product.dao1;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.product.Entity.ShoppingCart;

public interface CartRepository
{

	public List<ShoppingCart> findAll();
	public ShoppingCart save(ShoppingCart shoppingCartItem);
	public void deleteById(Integer cartItemId);
	public void deleteByBuyerId(Integer buyerId);
	public Optional<ShoppingCart> findById(Integer cartItemId);

}

