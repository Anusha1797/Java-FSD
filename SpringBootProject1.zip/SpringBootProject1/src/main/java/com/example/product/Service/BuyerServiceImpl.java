package com.example.product.Service;

import com.example.product.Dao.BuyerDao;
import com.example.product.model.Buyerdetails;

public class BuyerServiceImpl implements BuyerService
{
	private BuyerDao buyerdao;
	@Override
	public Buyerdetails addbuyer(Buyerdetails buyer) {
	
		return buyerdao.save(buyer);
	}

}
