package com.example.product.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.example.product.Service.CartItemService;

import com.example.product.model.ShoppingCart;

@RestController
public class ShoppingCartController 
{
	@Autowired
	private CartItemService cartservice;
	
	@RequestMapping(value="/cartitems")
	public CartItemService addcartitem(@RequestBody ShoppingCart cart)
	{
		return cartservice.addcartitem(cart);
	}
	
	@RequestMapping(value = "deleteById/{cartid}", method = RequestMethod.DELETE)
	public void deleteById(@PathVariable("cartid") Integer cartid) 
	{
		
		cartservice.deleteById(cartid);
	}
	@RequestMapping(value="/update", method = RequestMethod.PUT)
	public CartItemService updateItem(@RequestBody CartItemService cartitemservice) 
	{
		
		return cartservice.update(cartitemservice);
	}
	
}
