package com.example.product.Service;

import com.example.product.model.Buyerdetails;

public interface BuyerService
{
	public Buyerdetails addbuyer(Buyerdetails buyer);

}
