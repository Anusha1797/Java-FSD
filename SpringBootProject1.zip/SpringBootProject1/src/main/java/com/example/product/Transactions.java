package com.example.product;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
//import javax.persistence.TemporalType;

@Entity
public class Transactions implements Serializable
{
		@Id
		@GeneratedValue( strategy = GenerationType.IDENTITY)
		private int Transcationid;
		@Column(name="user_id")
		private int userid;
		private int sellerid;
		private String Transcationtype;
		//@Temporal(value = TemporalType.TIMESTAMP)
		private Date datetime;
		private String remarks;
		@ManyToOne
		@JoinColumn(name="buyerid_key")
		private Buyerdetails buyerdetails;
		
		public Transactions()
		{
			
		}

		public Transactions(int transcationid, int userid, int sellerid, String transcationtype, Date datetime,
				String remarks) {
			super();
			Transcationid = transcationid;
			this.userid = userid;
			this.sellerid = sellerid;
			Transcationtype = transcationtype;
			this.datetime = datetime;
			this.remarks = remarks;
		}

		public int getTranscationid() {
			return Transcationid;
		}

		public void setTranscationid(int transcationid) {
			Transcationid = transcationid;
		}

		public int getUserid() {
			return userid;
		}

		public void setUserid(int userid) {
			this.userid = userid;
		}

		public int getSellerid() {
			return sellerid;
		}

		public void setSellerid(int sellerid) {
			this.sellerid = sellerid;
		}

		public String getTranscationtype() {
			return Transcationtype;
		}

		public void setTranscationtype(String transcationtype) {
			Transcationtype = transcationtype;
		}

		public Date getDatetime() {
			return datetime;
		}

		public void setDatetime(Date datetime) {
			this.datetime = datetime;
		}

		public String getRemarks() {
			return remarks;
		}

		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}

		@Override
		public String toString() {
			return "Transactions [Transcationid=" + Transcationid + ", userid=" + userid + ", sellerid=" + sellerid
					+ ", Transcationtype=" + Transcationtype + ", datetime=" + datetime + ", remarks=" + remarks + "]";
		}
		
		
		
		
}
