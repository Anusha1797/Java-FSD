package com.example.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
/*@NamedQueries(value= {@NamedQuery(name = "retrieveall", query = "FROM OrderItem"),@NamedQuery(name = "retrieveCount", query = "SELECT count(*) FROM OrderItem") })*/
/*@NamedQuery(name = "retrieveCount", query = "SELECT count(*) FROM OrderItem")*/ 
@NamedQueries(value= {@NamedQuery(name = "retrieveall", query = "FROM OrderItem"),
		@NamedQuery(name = "retrieveCount", query = "SELECT count(*) FROM OrderItem")})

public class OrderItem {
	@Id
	private int id;
	@Column(name="order_id")
	private int orderid;
	@Column(name="total")
	private int total;
	@Column(name="product_id")
	private int productid;
	@Column(name="product_count")
	private int productcount;
	@Column(name="product_price")
	private int productprice;
	
	public OrderItem()
	{
		
	}

	public OrderItem(int id, int orderid, int total, int productid, int productcount, int productprice) 
	{
		this.id = id;
		this.orderid = orderid;
		this.total = total;
		this.productid = productid;
		this.productcount = productcount;
		this.productprice = productprice;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public int getProductcount() {
		return productcount;
	}

	public void setProductcount(int productcount) {
		this.productcount = productcount;
	}

	public int getProductprice() {
		return productprice;
	}

	public void setProductprice(int productprice) {
		this.productprice = productprice;
	}

	@Override
	public String toString() {
		return "OrderItem [id=" + id + ", orderid=" + orderid + ", total=" + total + ", productid=" + productid
				+ ", productcount=" + productcount + ", productprice=" + productprice + "]";
	}
	
	
	
}
