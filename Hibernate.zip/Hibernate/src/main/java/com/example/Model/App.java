package com.example.Model;



import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

public class App {

	public static void main(String[] args) 
	
	{
		Configuration configuration=new Configuration().configure();
		StandardServiceRegistryBuilder builder=new StandardServiceRegistryBuilder().applySettings(configuration.getProperties());
		SessionFactory factory=configuration.buildSessionFactory(builder.build());
		Session session=factory.openSession();
		Employee emp=new Employee(1001,"Alen","manager");
		Employee emp1=new Employee(1002,"John","admin");
//		OrderItem orderitem=new OrderItem(1001,6,51,144,23,565);
//		OrderItem orderitem1=new OrderItem(1002,8,14,119,38,540);
//		OrderItem orderitem2=new OrderItem(1003,7,14,119,38,540);
//		OrderItem orderitem3=new OrderItem(1004,9,51,119,38,540);
		
	
		session.beginTransaction();
		/*Serializable ob=session.save(emp);*/
//		session.saveOrUpdate(orderitem);
//		session.saveOrUpdate(orderitem1);
//		session.saveOrUpdate(orderitem2);
//		session.saveOrUpdate(orderitem3);
		session.getTransaction().commit();
		/*String qry="select order.productprice FROM OrderItem order";
		Query q=session.createQuery(qry);
		List<OrderItem> l=q.list();
		System.out.println(l);*/
		
		/*String hql="from OrderItem o where o.orderid=?";
		Query q1= session.createQuery(hql);
		q1.setParameter(0,8);
		List l1=q1.list();
		System.out.println(q1.list());*/
		
		/*String hql1="from OrderItem o where o.orderid=:orderid";
		orderitem.setOrderid(7);
		List list=session.createQuery(hql1).setProperties(orderitem).list();
		System.out.println(list);
		
		Query q2=session.createSQLQuery("select * from user_details");
		System.out.println(q2.list());*/
		
		/*Query q2=session.getNamedQuery("retrieveall");
		q2.setFirstResult(1);
		System.out.println(q2.list());*/
		//Query q3=session.getNamedQuery("retrieveCount");
		//System.out.println(q3.list());
		//q3.getFirstResult();
		//System.out.println(q3.list());
		
		Criteria crit=session.createCriteria(Employee.class);
		crit.add(Restrictions.like("empname","a%"));
		List<Employee> results=crit.list();
		System.out.println(results);
		
		
		
		
		
		
		session.close();
		
		
		
		// TODO Auto-generated method stub

	}

}
