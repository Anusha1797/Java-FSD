export class Cart {
    itemid: number;
    numberofitems: number;
    price: number
}