import { Component } from '@angular/core';
 import { SellerServiceService } from './seller-service.service';
import { Item } from './Item';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  {
  title = 'ProjectApp';
  name: String;
  item: Item[];

  constructor(private sellerservice: SellerServiceService) {
    console.log("constructor invoked");
  }
  mgOnInit() {
    this.name="";
  }
  searchitem() {
  
    this.sellerservice.getItemsByName(this.name).subscribe(Item=>this.item=Item);
    console.log("invoked searchitem()");
   //this.sellerservice.getItemsByName("T").subscribe(items=>{console.log("Item name is:"+items[0].itemname)});
  }

}
 
