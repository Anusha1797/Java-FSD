import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-displaycartitems',
  templateUrl: './displaycartitems.component.html',
  styleUrls: ['./displaycartitems.component.css']
})
export class DisplaycartitemsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
