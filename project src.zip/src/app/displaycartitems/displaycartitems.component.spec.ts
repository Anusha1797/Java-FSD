import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplaycartitemsComponent } from './displaycartitems.component';

describe('DisplaycartitemsComponent', () => {
  let component: DisplaycartitemsComponent;
  let fixture: ComponentFixture<DisplaycartitemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplaycartitemsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplaycartitemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
