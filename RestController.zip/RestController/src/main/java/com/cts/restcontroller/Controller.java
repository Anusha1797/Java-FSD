/*Controller*/
package com.cts.restcontroller;

import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonFormat.Value;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.web.bind.annotation.RequestMapping;


@RestController
public class Controller {
	List<Product> list=new ArrayList<>();
	Map<Integer,Product> m=new HashMap<>();
	
	public Controller()
	{
		list.add(new Product(1001,"Laptop",15,2344));
		list.add(new Product(1002,"Tv",8,4345));
		list.add(new Product(1003,"PC",10,8765));
		list.add(new Product(1004,"Mobile",9,6789));
		
		m.put(1001, new Product(1005,"aacc",5,8976));
		m.put(1002, new Product(1006,"aabb",6,5678));
		m.put(1003, new Product(1007,"bbcc",7,6789));
		m.put(1004, new Product(1009,"ddee",8,4567));	
	}
	

	@RequestMapping("/data")
	public Map getstring1()
	{
		return m;
	}
	
	@RequestMapping("/jsondata")
	public List getProduct()
	{
		return list;
    }
}
