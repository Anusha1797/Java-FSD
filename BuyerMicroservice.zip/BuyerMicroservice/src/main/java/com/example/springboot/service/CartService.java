package com.example.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springboot.dao.BuyerDao;
import com.example.springboot.dao.CartDao;
import com.example.springboot.entity.Buyer;
import com.example.springboot.entity.ShoppingCart;

@Service
public class CartService
{
	@Autowired
	private CartDao cartdao;
	@Autowired
	private BuyerDao buyerdao;
	
	
	public List<ShoppingCart> getcartitemsbyId(int Id)
	{
		return cartdao.findAll();
	}

	public String addcartItem(int bid, ShoppingCart cartitem) 
	{
		Buyer buyer= buyerdao.getOne(bid);
		cartitem.setBuyer(buyer);
		System.out.println(cartitem);
		cartdao.save(cartitem);
		return "item added";	
	}

	public List<ShoppingCart> getcartItemsById(int bid) {
		// TODO Auto-generated method stub
		return null;
	}
	

	
	

	
	}

	


