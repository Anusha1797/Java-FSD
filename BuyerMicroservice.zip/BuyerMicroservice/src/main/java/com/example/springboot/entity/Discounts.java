package com.example.springboot.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="discounts")
public class Discounts implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int discountId;
	private String discountCode;
	private float percentage;
	private Date StartDate;
	private Date EndDate;
	private String Description;
	public int getDiscountId() {
		return discountId;
	}
	public void setDiscountId(int discountId) {
		this.discountId = discountId;
	}
	public String getDiscountCode() {
		return discountCode;
	}
	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}
	public float getPercentage() {
		return percentage;
	}
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	public Date getStartDate() {
		return StartDate;
	}
	public void setStartDate(Date startDate) {
		StartDate = startDate;
	}
	public Date getEndDate() {
		return EndDate;
	}
	public void setEndDate(Date endDate) {
		EndDate = endDate;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	public Discounts(int discountId, String discountCode, float percentage, Date startDate, Date endDate,
			String description) {
		super();
		this.discountId = discountId;
		this.discountCode = discountCode;
		this.percentage = percentage;
		StartDate = startDate;
		EndDate = endDate;
		Description = description;
	}
	public Discounts() {
		super();
	}
	
	

}
