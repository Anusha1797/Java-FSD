package com.example.springboot.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.springboot.entity.ShoppingCart;
import com.example.springboot.service.CartService;

@RestController
//@RequestMapping("/cart")
public class ShoppingCartController 
{
	@Autowired
	private CartService service;
	
	@PostMapping("addcart/{bid}")
	public String addCartItem(@PathVariable(value = "buyerId") int bid, @RequestBody ShoppingCart cartitem) 
	{
		/*Optional<ShoppingCart> savedItem = service.addCartItem(cartItem,buyerId);
		System.out.println("controller");
		return savedItem.get();*/
		return service.addcartItem(bid, cartitem);				
	}
	public List<ShoppingCart> getCartItemById(int bid)
	{
		return service.getcartItemsById(bid);
	}

	
}
