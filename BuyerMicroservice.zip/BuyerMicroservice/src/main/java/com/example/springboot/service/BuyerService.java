package com.example.springboot.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springboot.dao.BuyerDao;
import com.example.springboot.entity.Buyer;
@Service
public class BuyerService 
{
	@Autowired
	private BuyerDao buyerdao;

	public List<Buyer> getAllBuyers() 
	{
		
		return buyerdao.findAll();
	}


	public Buyer addBuyer(Buyer buyer) {
		System.out.println("buyer");
		return buyerdao.save(buyer);
	}

	
	}


