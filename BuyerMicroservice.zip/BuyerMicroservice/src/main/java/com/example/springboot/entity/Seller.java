package com.example.springboot.entity;


public class Seller {

}
