package com.example.springboot.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.springboot.entity.Seller;

@Repository
public interface SellerDao extends JpaRepository<Seller,Integer> 
{


}
