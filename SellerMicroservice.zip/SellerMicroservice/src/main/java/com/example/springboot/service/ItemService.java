package com.example.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springboot.dao.ItemDao;
import com.example.springboot.dao.SellerDao;
import com.example.springboot.entity.Items;
import com.example.springboot.entity.Seller;

@Service
public class ItemService 
{
	@Autowired
	private ItemDao itemdao;
	@Autowired
	private SellerDao sellerdao;

	public List<Items> getAllItems() 
	{
		return itemdao.findAll() ;
	}

	public Items addItem(Items items, int sid)
	{
		Seller seller= sellerdao.getOne(sid);
		items.setSellerid(seller);
		return itemdao.save(items);
	}

	public List<Items> searchforitem(String name) 
	{
		return itemdao.findByName(name);
	}

	public void deleteitem(int sid)
	{
		
		itemdao.deletesellerid(sid);;
	}
	
	

}



