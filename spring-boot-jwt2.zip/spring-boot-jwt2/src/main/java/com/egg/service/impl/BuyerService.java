package com.egg.service.impl;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerDao;
import com.egg.model.Buyer;

/*import com.example.springboot.dao.BuyerDao;
import com.example.springboot.entity.Buyer;*/
@Service
public class BuyerService implements UserDetailsService 
{
	@Autowired
	private BuyerDao buyerdao;
	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Buyer buyer = buyerdao.findByUsername(username);
		if(buyer == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(buyer.getUsername(), buyer.getPassword(), getAuthority());
	}
	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}



	public List<Buyer> getAllBuyers() 
	{
		
		return buyerdao.findAll();
	}


	public Buyer addBuyer(Buyer buyer) {
		buyer.setPassword(bcryptEncoder.encode(buyer.getPassword()));
		return buyerdao.save(buyer);
	}
	
	public Buyer findOne(String username) {
		
		return buyerdao.findByUsername(username);
	}
	
	}


