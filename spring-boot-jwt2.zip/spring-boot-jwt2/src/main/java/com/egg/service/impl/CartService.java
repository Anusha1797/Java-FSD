package com.egg.service.impl;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerDao;
import com.egg.dao.CartDao;
import com.egg.model.Buyer;
import com.egg.model.ShoppingCart;


@Service
public class CartService
{
	@Autowired
	private CartDao cartdao;
	@Autowired
	private BuyerDao buyerdao;
	
	
	
	public ShoppingCart addcartItem(int bid, ShoppingCart cart) 
	{
		Buyer buyer=buyerdao.getOne(bid);
		cart.setBuyer(buyer);
		return cartdao.save(cart);
	}
	//public void deleteCartItem(int id)
	//{
		//return cartdao.deleteCartItem(id);
	//}
	public void deleteById(int bid) 
	{
		 cartdao.deleteById(bid);
	}
	public List<ShoppingCart> getCartItembyId(int bid) {
		
		return cartdao.findAll();
	}
	public void deleteAllCart() {
		cartdao.deleteAll();
	}
	public ShoppingCart updatecart(Integer cid, ShoppingCart cart)
	{
	
		Optional<ShoppingCart> c=cartdao.findById(cid);
		ShoppingCart cart1=null;
		if(c.isPresent())
		{
			cart1=c.get();
			cart1.setNumberofitems(cart.getNumberofitems());
			return cartdao.save(cart1);	
		}
		return null;
	}
	
	
	
	

	
	}

	


