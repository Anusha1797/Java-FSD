
package com.egg.controller;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.egg.model.Buyer;
import com.egg.service.impl.BuyerService;


/*import com.example.springboot.entity.Buyer;
import com.example.springboot.service.BuyerService;*/



@RestController
//@RequestMapping("/buyers")
public class BuyerController {
	@Autowired 
	private BuyerService service;

	//sample for getting buyers from database
	@RequestMapping("getAllBuyers")
	public List<Buyer> getAllBuyers()
	{
		return service.getAllBuyers();
	}	
	//adding buyer
	@RequestMapping(value="addbuyer" ,method=RequestMethod.POST,produces="application/json")
	public Buyer addBuyer(@RequestBody Buyer buyer)
	{
		System.out.println("buyer");
		return service.addBuyer(buyer);
		
	}
	
	/*@RequestMapping("getbyname/{name}")
	public Buyer getbyName(@PathVariable("bname") String name) {
	return service.getBuyerByName(name);
}*/
}
